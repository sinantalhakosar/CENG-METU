from random import seed

# fix randomness; DO NOT CHANGE THIS
seed(1234)

def getunique(list1): 
    return (list(set(list1))) 

def convert_to_ascii(somestring):
    return sum(ord(char) for char in somestring)

def normalize_data(somedataset):
    outcome, somelist = list(), list()
    for line in somedataset:
        somelist.append([convert_to_ascii(x) for x in line[0].split(",")[:-1]])
        outcome.append(convert_to_ascii(line[0].split(",")[-1]))
    return somelist, outcome

def load_dataset(somefilename):
    dataset = list()
    with open(somefilename, 'r') as file:
        dataset = [[line.strip()] for line in file]
    return normalize_data(dataset)

def generate_occurancy_probabilities(list1):
    return {i: list1.count(i) / float(len(list1)) for i in getunique(list1)}

def find_row_indices(list1,val):
    return [i for i,elem in enumerate(list1) if elem == val]

def generate_subset(list1,list2):
    return [list1[elem] for elem in list2]

def naive_bayes(train_path, test_path):
    """
    Performs naive Bayes classification
    :param train_path: path of the training set, a string
    :param test_path: path of the test set, a string
    :return: percent accuracy value for the test set, e.g., 85.43
    """
    trainsetX, trainsetY = load_dataset(train_path)
    testsetX, testsetY = load_dataset(test_path)
    classes = getunique(trainsetY)
    cols = len(trainsetX[0])
    relatives = dict()
    for cls in classes:
        if cls not in relatives:
            relatives[cls] = dict()
    class_probabilities = generate_occurancy_probabilities(trainsetY)
    for cls in classes:
        row_indices = find_row_indices(trainsetY,cls)
        subset = generate_subset(trainsetX,row_indices)
        r, c = len(subset), len(subset[0])
        for i in range(0,c):
            relatives[cls][i] = generate_occurancy_probabilities([subset[j][i] for j in range(r)])
    count = 0
    for index, row in enumerate(testsetX):
        probabilities = {}
        for cls in classes:
            class_probility = class_probabilities[cls]
            for i,val in enumerate(row):
                relative_values = relatives[cls][i]
                if val in relative_values:
                    class_probility *= relative_values[val]
                else:
                    class_probility = .0
                probabilities[cls] = class_probility
        if max(probabilities, key=lambda key: probabilities[key]) == testsetY[index]:
            count += 1
    #print((count/len(testsetY))*100)
    #return((count/len(testsetY))*100)
    return("{:.2f}".format((count/len(testsetY))*100))

#print(naive_bayes('task1_data/train.txt', 'task1_data/test.txt'))

